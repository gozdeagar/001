# Author: Thomas George Thomas
SELECT AVG(POPULATION)
FROM CITY
WHERE DISTRICT ='California'
