# Author: Thomas George Thomas
select * from city where countrycode="JPN";