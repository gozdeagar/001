# Author: Thomas George Thomas
SELECT * FROM CITY WHERE population > 100000 AND Countrycode ="USA";
