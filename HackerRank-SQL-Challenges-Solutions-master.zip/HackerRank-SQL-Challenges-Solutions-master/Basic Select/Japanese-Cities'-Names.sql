# Author: Thomas George Thomas
select name from city where CountryCode="JPN";