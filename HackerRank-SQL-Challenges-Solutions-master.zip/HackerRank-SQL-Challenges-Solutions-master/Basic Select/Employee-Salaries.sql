# Author: Thomas George Thomas
select name from employee where salary > 2000 and months <10 order By employee_id;