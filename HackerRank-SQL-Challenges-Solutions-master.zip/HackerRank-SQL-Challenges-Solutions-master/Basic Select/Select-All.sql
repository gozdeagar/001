# Author: Thomas George Thomas
Select * from city