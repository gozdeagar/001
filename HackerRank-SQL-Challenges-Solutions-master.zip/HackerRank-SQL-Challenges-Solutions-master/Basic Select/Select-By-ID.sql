# Author: Thomas George Thomas
select * from city where ID=1661;