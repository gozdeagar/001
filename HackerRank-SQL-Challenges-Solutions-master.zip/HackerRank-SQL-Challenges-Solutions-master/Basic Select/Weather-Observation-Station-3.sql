# Author: Thomas George Thomas
Select distinct city from station where ID%2=0;